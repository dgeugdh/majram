<?php
$NameServer = "Brhom"; // اسم السيرفر
$SQLNameUser = "keypro_D7"; // حساب القاعده
$SQLDBName = "keypro_brhom"; // اسم القاعده
$SQLPass = ""; // كلمه سر حساب القاعده
$NameKey = "brhom"; // اسم قبل الكود
$NameFolder = "ServerBrhom"; // اسم المجلد الي فيه ملفات Set,Sets
?>